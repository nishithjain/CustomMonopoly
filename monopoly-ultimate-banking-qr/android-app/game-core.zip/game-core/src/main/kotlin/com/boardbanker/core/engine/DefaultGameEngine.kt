package com.boardbanker.core.engine

import com.boardbanker.core.command.GameCommand
import com.boardbanker.core.dice.DiceRoller
import com.boardbanker.core.dice.RandomDiceRoller
import com.boardbanker.core.error.GameError
import com.boardbanker.core.event.EventEngine
import com.boardbanker.core.model.AuctionState
import com.boardbanker.core.model.ColorGroupState
import com.boardbanker.core.model.DebtReason
import com.boardbanker.core.model.EntityRef
import com.boardbanker.core.model.EnergyGridState
import com.boardbanker.core.model.GameDefinitions
import com.boardbanker.core.model.GameSession
import com.boardbanker.core.model.GameStatus
import com.boardbanker.core.model.PlayerState
import com.boardbanker.core.model.PropertyState
import com.boardbanker.core.model.TransactionType
import com.boardbanker.core.rules.BankruptcyRules
import com.boardbanker.core.rules.ColorSetRules
import com.boardbanker.core.rules.DebtRules
import com.boardbanker.core.rules.EnergyGridRentRules
import com.boardbanker.core.rules.EnergyGridRules
import com.boardbanker.core.rules.GoRules
import com.boardbanker.core.rules.JailGameplayGuard
import com.boardbanker.core.rules.JailRules
import com.boardbanker.core.rules.PropertyRules
import com.boardbanker.core.rules.RentRules
import com.boardbanker.core.rules.TurnScheduler
import com.boardbanker.core.rules.UndoSupport
import com.boardbanker.core.rules.WinnerCalculator
import com.boardbanker.core.transaction.TransactionFactory
import com.boardbanker.core.validation.PlayerNameRules
import kotlinx.serialization.json.intOrNull

class DefaultGameEngine(
    private val definitions: GameDefinitions,
    private val diceRoller: DiceRoller = RandomDiceRoller(),
) : GameEngine {
    private val transactionFactory = TransactionFactory()
    private val colorSetRules = ColorSetRules(definitions, transactionFactory)
    private val propertyRules = PropertyRules(definitions, colorSetRules, transactionFactory)
    private val energyGridRules = EnergyGridRules(definitions, transactionFactory)
    private val winnerCalculator = WinnerCalculator(definitions)
    private val bankruptcyRules = BankruptcyRules(definitions, transactionFactory, winnerCalculator)
    private val debtRules = DebtRules(definitions, transactionFactory, bankruptcyRules)
    private val rentRules = RentRules(definitions, transactionFactory, debtRules)
    private val energyGridRentRules = EnergyGridRentRules(definitions, transactionFactory, debtRules)
    private val goRules = GoRules(definitions, transactionFactory)
    private val jailRules = JailRules(definitions, transactionFactory)
    private val turnScheduler = TurnScheduler(transactionFactory)
    private val undoSupport = UndoSupport(definitions, transactionFactory)
    private val eventEngine = EventEngine(definitions, transactionFactory, jailRules, debtRules, turnScheduler)

    private val rules = definitions.rules
    private val policies = definitions.policies
    private val banking = definitions.bankingValues

    override fun process(session: GameSession, command: GameCommand): GameResult {
        return when (command) {
            is GameCommand.CreateGame -> handleCreateGame(session, command)
            is GameCommand.RegisterPlayer -> handleRegisterPlayer(session, command)
            is GameCommand.RenamePlayer -> handleRenamePlayer(session, command)
            is GameCommand.StartGame -> handleStartGame(session)
            is GameCommand.ProcessPropertyLanding -> handlePropertyLanding(session, command)
            is GameCommand.ProcessEnergyGridLanding -> handleEnergyGridLanding(session, command)
            is GameCommand.PurchaseProperty -> handlePurchase(session, command)
            is GameCommand.PurchaseEnergyGrid -> handlePurchaseEnergyGrid(session, command)
            is GameCommand.ApplyEvent -> handleApplyEvent(session, command)
            is GameCommand.CancelEventPreview -> handleCancelEventPreview(session, command)
            is GameCommand.EventPropertyChoice -> handleEventPropertyChoice(session, command)
            is GameCommand.PayGoSalary -> handlePayGo(session, command)
            is GameCommand.PayLocationFee -> handleLocationFee(session, command)
            is GameCommand.SendPlayerToJail -> handleSendToJail(session, command)
            is GameCommand.PayJailFee -> handlePayJailFee(session, command)
            is GameCommand.ReleasePlayerFromJailByPayment -> handlePayJailFee(
                session,
                GameCommand.PayJailFee(command.playerId, command.restrictToActivePlayer),
            )
            is GameCommand.ReleasePlayerFromJailByDoubles -> handleReleaseByDoubles(session, command)
            is GameCommand.UseGetOutOfJailPass -> handleUseGetOutOfJailPass(session, command)
            is GameCommand.GetOutOfJailWithPass -> handleGetOutOfJailWithPass(session, command)
            is GameCommand.StartAuction -> handleStartAuction(session, command)
            is GameCommand.PlaceAuctionBid -> handlePlaceBid(session, command)
            is GameCommand.CompleteAuction -> handleCompleteAuction(session)
            is GameCommand.CancelAuction -> handleCancelAuction(session)
            is GameCommand.ResolveDebt -> handleResolveDebt(session, command)
            is GameCommand.ResolveDebtWithProperties -> handleResolveDebtWithProperties(session, command)
            is GameCommand.CheckBankruptcy -> handleCheckBankruptcy(session, command)
            is GameCommand.UndoLastAction -> handleUndo(session)
            is GameCommand.ConcludeGame -> handleConcludeGame(session)
            is GameCommand.EndTurn -> handleEndTurn(session, command)
            is GameCommand.RollEventDice -> handleRollEventDice(session, command)
            is GameCommand.SelectDiceGambleMode -> handleSelectDiceGambleMode(session, command)
            is GameCommand.ResetDiceGambleMode -> handleResetDiceGambleMode(session, command)
            is GameCommand.ResolvePhysicalDiceGamble -> handleResolvePhysicalDiceGamble(session, command)
            is GameCommand.ResolvePendingEventDraw -> handleResolvePendingEventDraw(session, command)
        }
    }

    private fun handleCreateGame(session: GameSession, command: GameCommand.CreateGame): GameResult {
        return GameResult(
            session.copy(
                gameId = command.gameId,
                status = GameStatus.SETUP,
            ),
        )
    }

    private fun handleRegisterPlayer(
        session: GameSession,
        command: GameCommand.RegisterPlayer,
    ): GameResult {
        if (session.status != GameStatus.SETUP) {
            return reject(session, GameError.InvalidState("Cannot register players after game started"))
        }
        if (!definitions.players.containsKey(command.playerId)) {
            return reject(session, GameError.NotFound("Player", command.playerId))
        }
        if (session.players.containsKey(command.playerId)) {
            return reject(session, GameError.DuplicatePlayer(command.playerId))
        }
        if (session.players.size >= rules.maximumPlayers) {
            return reject(session, GameError.PlayerLimit("Maximum ${rules.maximumPlayers} players"))
        }
        val nameValidation = PlayerNameRules.validate(command.playerName)
        if (nameValidation is PlayerNameRules.ValidationResult.Invalid) {
            return reject(session, nameValidation.error)
        }
        val playerName = (nameValidation as PlayerNameRules.ValidationResult.Valid).name
        val updated = session.copy(
            players = session.players + (
                command.playerId to PlayerState(
                    playerId = command.playerId,
                    playerName = playerName,
                    balance = banking.startingBalance,
                )
            ),
            playerJoinOrder = session.playerJoinOrder + command.playerId,
        )
        return GameResult(updated)
    }

    private fun handleRenamePlayer(
        session: GameSession,
        command: GameCommand.RenamePlayer,
    ): GameResult {
        if (session.status != GameStatus.SETUP) {
            return reject(session, GameError.InvalidState("Cannot rename players after game started"))
        }
        if (!session.players.containsKey(command.playerId)) {
            return reject(session, GameError.NotFound("Player", command.playerId))
        }
        val nameValidation = PlayerNameRules.validate(command.playerName)
        if (nameValidation is PlayerNameRules.ValidationResult.Invalid) {
            return reject(session, nameValidation.error)
        }
        val playerName = (nameValidation as PlayerNameRules.ValidationResult.Valid).name
        val player = session.players[command.playerId]!!
        val updated = session.copy(
            players = session.players + (command.playerId to player.copy(playerName = playerName)),
        )
        return GameResult(updated)
    }

    private fun handleStartGame(session: GameSession): GameResult {
        if (session.status != GameStatus.SETUP) {
            return reject(session, GameError.InvalidState("Game already started"))
        }
        if (session.players.size < rules.minimumPlayers) {
            return reject(session, GameError.Validation("Need at least ${rules.minimumPlayers} players"))
        }
        val properties = definitions.properties.values.associate { def ->
            def.propertyId to PropertyState(
                propertyId = def.propertyId,
                ownerPlayerId = null,
                currentRentLevel = def.initialRentLevel,
            )
        }
        val energyGrids = definitions.energyGrids.values.associate { def ->
            def.energyGridId to EnergyGridState(
                energyGridId = def.energyGridId,
                ownerPlayerId = null,
            )
        }
        val colorGroups = definitions.boardRelationships.colorGroups.keys.associateWith { group ->
            ColorGroupState(colorGroup = group)
        }
        val players = session.players.mapValues { (_, player) ->
            player.copy(balance = banking.startingBalance, active = true, bankrupt = false, jailStatus = false)
        }
        var updated = session.copy(
            status = GameStatus.ACTIVE,
            players = players,
            properties = properties,
            energyGrids = energyGrids,
            colorGroups = colorGroups,
            turnState = TurnScheduler.initialTurnState(session.playerJoinOrder, players),
        )
        val (tx, sessionAfter) = transactionFactory.create(
            session = updated,
            type = TransactionType.GAME_START,
        )
        return GameResult(sessionAfter, transactions = listOf(tx))
    }

    private fun handlePropertyLanding(
        session: GameSession,
        command: GameCommand.ProcessPropertyLanding,
    ): GameResult {
        if (session.status != GameStatus.ACTIVE) {
            return reject(session, GameError.GameFinished)
        }
        activeTurnLandingValidation(session, command.playerId)?.let {
            return reject(session, it)
        }
        JailGameplayGuard.propertyPurchaseBlockedMessage(definitions, session, command.playerId)?.let {
            return reject(session, GameError.Validation(it))
        }
        val propertyState = session.properties[command.propertyId]
            ?: return reject(session, GameError.NotFound("Property", command.propertyId))
        when (propertyState.ownerPlayerId) {
            null -> return GameResult(
                session = session,
                outcome = GameOutcome.PENDING_ACTION,
                pendingMessage = "Property unowned: choose BUY or AUCTION",
            )
            command.playerId -> {
                val result = propertyRules.ownerLandsOnOwnProperty(
                    session, command.playerId, command.propertyId,
                )
                if (!result.isSuccess) {
                    return reject(session, GameError.Validation(result.error!!))
                }
                return GameResult(result.session!!, transactions = result.transactions)
            }
            else -> {
                val result = rentRules.processVisitorRent(
                    session, command.playerId, command.propertyId,
                )
                if (!result.isSuccess) {
                    return reject(session, GameError.Validation(result.error!!))
                }
                val outcome = if (result.session!!.debtResolution != null) {
                    GameOutcome.DEBT_RESOLUTION_REQUIRED
                } else {
                    GameOutcome.SUCCESS
                }
                return GameResult(result.session, outcome = outcome, transactions = result.transactions)
            }
        }
    }

    private fun handlePurchase(
        session: GameSession,
        command: GameCommand.PurchaseProperty,
    ): GameResult {
        val propertyDef = definitions.properties[command.propertyId]
            ?: return reject(session, GameError.NotFound("Property", command.propertyId))
        val buyer = session.players[command.playerId]
            ?: return reject(session, GameError.NotFound("Player", command.playerId))
        JailGameplayGuard.propertyPurchaseBlockedMessage(definitions, session, command.playerId)?.let {
            return reject(session, GameError.Validation(it))
        }
        if (buyer.balance < propertyDef.purchasePrice) {
            val debtResult = debtRules.enterDebtResolution(
                session = session,
                debtorId = command.playerId,
                creditorId = EntityRef.BANK,
                amount = propertyDef.purchasePrice,
                reason = DebtReason.PURCHASE,
                propertyId = command.propertyId,
            )
            if (!debtResult.isSuccess) {
                return reject(session, GameError.Validation(debtResult.error!!))
            }
            return GameResult(
                session = debtResult.session!!,
                outcome = GameOutcome.DEBT_RESOLUTION_REQUIRED,
                transactions = debtResult.transactions,
            )
        }
        val result = propertyRules.purchaseProperty(session, command.playerId, command.propertyId)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleEnergyGridLanding(
        session: GameSession,
        command: GameCommand.ProcessEnergyGridLanding,
    ): GameResult {
        if (session.status != GameStatus.ACTIVE) {
            return reject(session, GameError.GameFinished)
        }
        activeTurnLandingValidation(session, command.playerId)?.let {
            return reject(session, it)
        }
        JailGameplayGuard.propertyPurchaseBlockedMessage(definitions, session, command.playerId)?.let {
            return reject(session, GameError.Validation(it))
        }
        val gridState = session.energyGrids[command.energyGridId]
            ?: return reject(session, GameError.NotFound("EnergyGrid", command.energyGridId))
        when (gridState.ownerPlayerId) {
            null -> return GameResult(
                session = session.copy(pendingEnergyGridLanding = null),
                outcome = GameOutcome.PENDING_ACTION,
                pendingMessage = "Energy grid unowned: choose BUY or AUCTION",
            )
            command.playerId -> {
                val result = energyGridRules.ownerLandsOnOwnGrid(
                    session, command.playerId, command.energyGridId,
                )
                if (!result.isSuccess) {
                    return reject(session, GameError.Validation(result.error!!))
                }
                return GameResult(result.session!!, transactions = result.transactions)
            }
            else -> {
                val result = energyGridRentRules.processVisitorRent(
                    session, command.playerId, command.energyGridId,
                )
                if (!result.isSuccess) {
                    return reject(session, GameError.Validation(result.error!!))
                }
                val outcome = if (result.session!!.debtResolution != null) {
                    GameOutcome.DEBT_RESOLUTION_REQUIRED
                } else {
                    GameOutcome.SUCCESS
                }
                return GameResult(result.session, outcome = outcome, transactions = result.transactions)
            }
        }
    }

    private fun handlePurchaseEnergyGrid(
        session: GameSession,
        command: GameCommand.PurchaseEnergyGrid,
    ): GameResult {
        val gridDef = definitions.energyGrids[command.energyGridId]
            ?: return reject(session, GameError.NotFound("EnergyGrid", command.energyGridId))
        val buyer = session.players[command.playerId]
            ?: return reject(session, GameError.NotFound("Player", command.playerId))
        JailGameplayGuard.propertyPurchaseBlockedMessage(definitions, session, command.playerId)?.let {
            return reject(session, GameError.Validation(it))
        }
        if (buyer.balance < gridDef.purchasePrice) {
            val debtResult = debtRules.enterDebtResolution(
                session = session,
                debtorId = command.playerId,
                creditorId = EntityRef.BANK,
                amount = gridDef.purchasePrice,
                reason = DebtReason.PURCHASE,
                propertyId = command.energyGridId,
            )
            if (!debtResult.isSuccess) {
                return reject(session, GameError.Validation(debtResult.error!!))
            }
            return GameResult(
                session = debtResult.session!!,
                outcome = GameOutcome.DEBT_RESOLUTION_REQUIRED,
                transactions = debtResult.transactions,
            )
        }
        val result = energyGridRules.purchaseEnergyGrid(session, command.playerId, command.energyGridId)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleApplyEvent(
        session: GameSession,
        command: GameCommand.ApplyEvent,
    ): GameResult {
        if (session.pendingEventDraw != null) {
            return reject(
                session,
                GameError.InvalidState("Resolve the Lucky Draw before applying another event"),
            )
        }
        val result = eventEngine.apply(
            session = session,
            eventId = command.eventId,
            actingPlayerId = command.actingPlayerId,
            propertyId = command.propertyId,
            targetPlayerId = command.targetPlayerId,
            secondPropertyId = command.secondPropertyId,
            secondPlayerId = command.secondPlayerId,
            fromBoardPosition = command.fromBoardPosition,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.EventError(result.error!!))
        }
        val outcome = when {
            result.needsDebtResolution -> GameOutcome.DEBT_RESOLUTION_REQUIRED
            result.pendingMessage != null -> GameOutcome.PENDING_ACTION
            else -> GameOutcome.SUCCESS
        }
        return GameResult(
            session = result.session!!,
            outcome = outcome,
            transactions = result.transactions,
            physicalActions = result.physicalActions,
            pendingMessage = result.pendingMessage,
            skippedTurnPlayerIds = result.skippedTurnPlayerIds,
            extraTurnStartedPlayerId = result.extraTurnStartedPlayerId,
            extraTurnCancelledBySkipPlayerId = result.extraTurnCancelledBySkipPlayerId,
        )
    }

    private fun handleCancelEventPreview(
        session: GameSession,
        command: GameCommand.CancelEventPreview,
    ): GameResult {
        if (!definitions.events.containsKey(command.eventId)) {
            return reject(session, GameError.NotFound("Event", command.eventId))
        }
        val committedEventAction = session.transactions.any { transaction ->
            transaction.eventId == command.eventId && transaction.playerId == command.actingPlayerId &&
                transaction.transactionType in setOf(
                    TransactionType.EVENT_APPLIED,
                    TransactionType.EVENT_PLAYER_TRANSFER,
                    TransactionType.EVENT_MULTI_PLAYER_TRANSFER,
                    TransactionType.BANK_DEBIT,
                    TransactionType.BANK_CREDIT,
                    TransactionType.RENT_DEBT_SETTLED,
                    TransactionType.BANKRUPTCY,
                )
        }
        val resolutionBelongsToEvent = session.pendingEventResolution?.let { resolution ->
            resolution.eventId == command.eventId && resolution.actingPlayerId == command.actingPlayerId
        } == true
        val debtBelongsToEvent = session.debtResolution?.let { debt ->
            debt.eventDebt?.eventId == command.eventId ||
                debt.eventContributorDebt?.eventId == command.eventId ||
                debt.eventBankDebit?.eventId == command.eventId
        } == true
        if (committedEventAction || resolutionBelongsToEvent && session.pendingEventResolution?.bankingRecorded == true) {
            return reject(
                session,
                GameError.InvalidState("This Event has already been applied and cannot be cancelled"),
            )
        }
        if (debtBelongsToEvent) {
            return reject(session, GameError.InvalidState("This Event has already created a debt and cannot be cancelled"))
        }
        if (session.debtResolution != null && !resolutionBelongsToEvent) {
            return reject(session, GameError.InvalidState("Resolve the active debt before cancelling an Event"))
        }
        return GameResult(
            session = session.copy(
                debtResolution = null,
                pendingEventChoice = null,
                pendingEventExecution = null,
                pendingEventResolution = null,
                pendingEventMultiContributorSettlement = null,
                pendingDiceGamble = null,
                eventChainDepth = if (session.pendingEventDraw == null) 0 else session.eventChainDepth,
            ),
        )
    }

    private fun handleResolvePendingEventDraw(
        session: GameSession,
        command: GameCommand.ResolvePendingEventDraw,
    ): GameResult {
        val pending = session.pendingEventDraw
            ?: return reject(session, GameError.InvalidState("No pending event draw"))
        if (pending.remainingDraws <= 0) {
            return reject(session, GameError.InvalidState("No pending event draw"))
        }
        if (command.actingPlayerId != pending.actingPlayerId) {
            return reject(session, GameError.Validation("Acting player mismatch for pending event draw"))
        }
        val turnState = session.turnState
            ?: return reject(session, GameError.InvalidState("Turn order is not initialized"))
        if (turnState.activePlayerId != command.actingPlayerId) {
            return reject(session, GameError.Validation("Not this player's turn"))
        }
        if (!definitions.events.containsKey(command.eventId)) {
            return reject(session, GameError.NotFound("Event", command.eventId))
        }
        if (command.eventId == pending.parentEventId) {
            return reject(
                session,
                GameError.EventError("This Event would start another Lucky Draw. Scan a different Event Card."),
            )
        }
        val event = definitions.events[command.eventId]!!
        if (event.actions.any { it.actionType == "DRAW_ANOTHER_EVENT" }) {
            return reject(
                session,
                GameError.EventError("This Event would start another Lucky Draw. Scan a different Event Card."),
            )
        }
        val preparedSession = session.copy(
            pendingEventDraw = null,
            pendingEventExecution = null,
        )
        val result = eventEngine.apply(
            session = preparedSession,
            eventId = command.eventId,
            actingPlayerId = command.actingPlayerId,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.EventError(result.error!!))
        }
        val outcome = when {
            result.needsDebtResolution -> GameOutcome.DEBT_RESOLUTION_REQUIRED
            result.pendingMessage != null -> GameOutcome.PENDING_ACTION
            else -> GameOutcome.SUCCESS
        }
        val updatedSession = result.session!!.copy(eventChainDepth = 0)
        return GameResult(
            session = updatedSession,
            outcome = outcome,
            transactions = result.transactions,
            physicalActions = result.physicalActions,
            pendingMessage = result.pendingMessage,
            skippedTurnPlayerIds = result.skippedTurnPlayerIds,
            extraTurnStartedPlayerId = result.extraTurnStartedPlayerId,
            extraTurnCancelledBySkipPlayerId = result.extraTurnCancelledBySkipPlayerId,
        )
    }

    private fun handleResetDiceGambleMode(
        session: GameSession,
        command: GameCommand.ResetDiceGambleMode,
    ): GameResult {
        val result = eventEngine.resetDiceGambleMode(
            session = session,
            eventId = command.eventId,
            actingPlayerId = command.actingPlayerId,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.EventError(result.error!!))
        }
        return GameResult(session = result.session!!, transactions = result.transactions)
    }

    private fun handleSelectDiceGambleMode(
        session: GameSession,
        command: GameCommand.SelectDiceGambleMode,
    ): GameResult {
        val result = eventEngine.selectDiceGambleMode(
            session = session,
            eventId = command.eventId,
            actingPlayerId = command.actingPlayerId,
            mode = command.mode,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.EventError(result.error!!))
        }
        return GameResult(session = result.session!!, transactions = result.transactions)
    }

    private fun handleResolvePhysicalDiceGamble(
        session: GameSession,
        command: GameCommand.ResolvePhysicalDiceGamble,
    ): GameResult {
        val pending = session.pendingDiceGamble
            ?: return reject(session, GameError.InvalidState("No dice gamble in progress"))
        if (session.turnState?.activePlayerId != command.actingPlayerId) {
            return reject(session, GameError.InvalidState("Only the active player can resolve Lucky Break"))
        }
        val result = eventEngine.resolvePhysicalDiceGamble(
            session = session,
            eventId = command.eventId,
            actingPlayerId = command.actingPlayerId,
            outcome = command.outcome,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.EventError(result.error!!))
        }
        val outcome = when {
            result.needsDebtResolution -> GameOutcome.DEBT_RESOLUTION_REQUIRED
            else -> GameOutcome.SUCCESS
        }
        return GameResult(
            session = result.session!!,
            outcome = outcome,
            transactions = result.transactions,
        )
    }

    private fun handleRollEventDice(
        session: GameSession,
        command: GameCommand.RollEventDice,
    ): GameResult {
        val pending = session.pendingDiceGamble
            ?: return reject(session, GameError.InvalidState("No dice gamble in progress"))
        if (session.turnState?.activePlayerId != command.actingPlayerId) {
            return reject(session, GameError.InvalidState("Only the active player can roll Lucky Break dice"))
        }
        val rolled = diceRoller.roll()
        val diceResults = if (pending.diceCount == 2) {
            rolled.asList()
        } else {
            List(pending.diceCount) { index -> rolled.asList().getOrElse(index) { rolled.die1 } }
        }
        val result = eventEngine.rollEventDice(
            session = session,
            eventId = command.eventId,
            actingPlayerId = command.actingPlayerId,
            diceResults = diceResults,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.EventError(result.error!!))
        }
        val outcome = when {
            result.needsDebtResolution -> GameOutcome.DEBT_RESOLUTION_REQUIRED
            result.pendingMessage != null -> GameOutcome.PENDING_ACTION
            else -> GameOutcome.SUCCESS
        }
        return GameResult(
            session = result.session!!,
            outcome = outcome,
            transactions = result.transactions,
            pendingMessage = result.pendingMessage,
            rolledDice = diceResults,
        )
    }

    private fun handleEventPropertyChoice(
        session: GameSession,
        command: GameCommand.EventPropertyChoice,
    ): GameResult {
        val pending = session.pendingEventChoice
            ?: return reject(session, GameError.InvalidState("No pending event choice"))
        val baseSession = session.copy(pendingEventChoice = null)
        val choiceResult = when (command.choice) {
            GameCommand.EventPropertyChoiceType.BUY -> {
                val purchase = propertyRules.purchaseProperty(
                    baseSession,
                    command.actingPlayerId,
                    command.propertyId,
                )
                if (!purchase.isSuccess) {
                    return reject(session, GameError.Validation(purchase.error!!))
                }
                GameResult(purchase.session!!, transactions = purchase.transactions)
            }
            GameCommand.EventPropertyChoiceType.AUCTION -> {
                handleStartAuction(
                    baseSession,
                    GameCommand.StartAuction(
                        propertyId = command.propertyId,
                        startedByPlayerId = command.actingPlayerId,
                    ),
                )
            }
            GameCommand.EventPropertyChoiceType.RAISE_RENT_LEVEL -> {
                val propertyState = session.properties[command.propertyId]
                if (propertyState?.ownerPlayerId != command.actingPlayerId) {
                    return reject(session, GameError.Validation("Must own property to raise rent"))
                }
                val result = propertyRules.ownerLandsOnOwnProperty(
                    baseSession,
                    command.actingPlayerId,
                    command.propertyId,
                )
                if (!result.isSuccess) {
                    return reject(session, GameError.Validation(result.error!!))
                }
                GameResult(result.session!!, transactions = result.transactions)
            }
        }
        return continuePendingEventExecution(choiceResult)
    }

    private fun continuePendingEventExecution(result: GameResult): GameResult {
        val pendingExecution = result.session.pendingEventExecution ?: return result
        val continueResult = eventEngine.apply(
            session = result.session,
            eventId = pendingExecution.eventId,
            actingPlayerId = pendingExecution.actingPlayerId,
            propertyId = pendingExecution.propertyId,
            targetPlayerId = pendingExecution.targetPlayerId,
            secondPropertyId = pendingExecution.secondPropertyId,
            secondPlayerId = pendingExecution.secondPlayerId,
        )
        if (!continueResult.isSuccess) {
            return reject(result.session, GameError.EventError(continueResult.error!!))
        }
        val outcome = when {
            continueResult.needsDebtResolution -> GameOutcome.DEBT_RESOLUTION_REQUIRED
            continueResult.pendingMessage != null -> GameOutcome.PENDING_ACTION
            else -> result.outcome
        }
        return GameResult(
            session = continueResult.session!!,
            outcome = outcome,
            transactions = result.transactions + continueResult.transactions,
            physicalActions = result.physicalActions + continueResult.physicalActions,
            pendingMessage = continueResult.pendingMessage ?: result.pendingMessage,
        )
    }

    private fun handlePayGo(
        session: GameSession,
        command: GameCommand.PayGoSalary,
    ): GameResult {
        if (command.reason == com.boardbanker.core.model.GoCollectionReason.MANUAL_BANK_ACTION) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
            bankActionBlockedWhileJailed(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val result = goRules.payGoSalary(session, command.playerId, command.reason)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleLocationFee(
        session: GameSession,
        command: GameCommand.PayLocationFee,
    ): GameResult {
        if (command.restrictToActivePlayer) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
            bankActionBlockedWhileJailed(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val player = session.players[command.playerId]
            ?: return reject(session, GameError.NotFound("Player", command.playerId))
        val fee = banking.locationFee
        if (player.balance < fee) {
            val debtResult = debtRules.enterDebtResolution(
                session = session,
                debtorId = command.playerId,
                creditorId = EntityRef.BANK,
                amount = fee,
                reason = DebtReason.LOCATION,
                propertyId = command.targetPropertyId,
            )
            if (!debtResult.isSuccess) {
                return reject(session, GameError.Validation(debtResult.error!!))
            }
            return GameResult(
                session = debtResult.session!!,
                outcome = GameOutcome.DEBT_RESOLUTION_REQUIRED,
                transactions = debtResult.transactions,
            )
        }
        val updatedPlayer = player.copy(balance = player.balance - fee)
        var updated = session.copy(players = session.players + (command.playerId to updatedPlayer))
        val (feeTx, sessionAfterFee) = transactionFactory.create(
            session = updated,
            type = TransactionType.LOCATION_FEE,
            fromEntity = command.playerId,
            toEntity = EntityRef.BANK,
            playerId = command.playerId,
            amount = fee,
            reversible = true,
        )
        updated = sessionAfterFee.copy(undoSnapshot = session.snapshot())

        val propertyState = updated.properties[command.targetPropertyId]
        if (propertyState == null) {
            return GameResult(updated, transactions = listOf(feeTx))
        }
        when (propertyState.ownerPlayerId) {
            null -> {
                return GameResult(
                    updated,
                    transactions = listOf(feeTx),
                    outcome = GameOutcome.PENDING_ACTION,
                    pendingMessage = "Purchase available for ${command.targetPropertyId}",
                )
            }
            command.playerId -> {
                val landing = propertyRules.ownerLandsOnOwnProperty(
                    updated,
                    command.playerId,
                    command.targetPropertyId,
                )
                return GameResult(
                    landing.session ?: updated,
                    transactions = listOf(feeTx) + landing.transactions,
                )
            }
            else -> {
                val rent = rentRules.processVisitorRent(
                    updated,
                    command.playerId,
                    command.targetPropertyId,
                )
                return GameResult(
                    rent.session ?: updated,
                    transactions = listOf(feeTx) + rent.transactions,
                )
            }
        }
    }

    private fun handleSendToJail(
        session: GameSession,
        command: GameCommand.SendPlayerToJail,
    ): GameResult {
        if (command.restrictToActivePlayer) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
            bankActionBlockedWhileJailed(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val result = jailRules.sendToJail(session, command.playerId)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(
            session = result.session!!,
            transactions = result.transactions,
            extraTurnCancelledByJailPlayerIds = extraTurnCancelledByJailPlayerIds(result.transactions),
        )
    }

    private fun handlePayJailFee(
        session: GameSession,
        command: GameCommand.PayJailFee,
    ): GameResult {
        if (command.restrictToActivePlayer) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val result = jailRules.payJailFee(session, command.playerId)
        if (result.needsDebtResolution) {
            val debtResult = debtRules.enterDebtResolution(
                session = session,
                debtorId = command.playerId,
                creditorId = EntityRef.BANK,
                amount = result.debtAmount,
                reason = DebtReason.JAIL,
            )
            if (!debtResult.isSuccess) {
                return reject(session, GameError.Validation(debtResult.error!!))
            }
            return GameResult(
                session = debtResult.session!!,
                outcome = GameOutcome.DEBT_RESOLUTION_REQUIRED,
                transactions = debtResult.transactions,
            )
        }
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleReleaseByDoubles(
        session: GameSession,
        command: GameCommand.ReleasePlayerFromJailByDoubles,
    ): GameResult {
        if (command.restrictToActivePlayer) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val result = jailRules.releaseByDoubles(session, command.playerId)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleUseGetOutOfJailPass(
        session: GameSession,
        command: GameCommand.UseGetOutOfJailPass,
    ): GameResult {
        if (command.restrictToActivePlayer) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val result = jailRules.useGetOutOfJailPass(session, command.playerId)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleGetOutOfJailWithPass(
        session: GameSession,
        command: GameCommand.GetOutOfJailWithPass,
    ): GameResult {
        if (command.restrictToActivePlayer) {
            activeTurnBankActionValidation(session, command.playerId)?.let {
                return reject(session, it)
            }
        }
        val result = jailRules.releaseWithScannedJailPass(
            session = session,
            playerId = command.playerId,
            eventId = command.eventId,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleEndTurn(
        session: GameSession,
        command: GameCommand.EndTurn,
    ): GameResult {
        val result = turnScheduler.endTurn(session, command.playerId)
        if (!result.isSuccess) {
            return reject(session, GameError.Validation(result.error!!))
        }
        return GameResult(
            session = result.session!!,
            transactions = result.transactions,
            skippedTurnPlayerIds = result.skippedTurnPlayerIds,
            extraTurnStartedPlayerId = result.extraTurnStartedPlayerId,
            extraTurnCancelledBySkipPlayerId = result.extraTurnCancelledBySkipPlayerId,
        )
    }

    private fun handleStartAuction(
        session: GameSession,
        command: GameCommand.StartAuction,
    ): GameResult {
        if (session.auction != null) {
            return reject(session, GameError.AuctionError("Auction already in progress"))
        }
        JailGameplayGuard.boardActionBlockedMessage(definitions, session, command.startedByPlayerId)?.let {
            return reject(session, GameError.Validation(it))
        }
        val auction = when {
            command.propertyId != null -> {
                val propertyState = session.properties[command.propertyId]
                    ?: return reject(session, GameError.NotFound("Property", command.propertyId))
                if (propertyState.ownerPlayerId != null) {
                    return reject(session, GameError.AuctionError("Property is already owned"))
                }
                AuctionState(
                    propertyId = command.propertyId,
                    startedByPlayerId = command.startedByPlayerId,
                )
            }
            command.energyGridId != null -> {
                val gridState = session.energyGrids[command.energyGridId]
                    ?: return reject(session, GameError.NotFound("EnergyGrid", command.energyGridId))
                if (gridState.ownerPlayerId != null) {
                    return reject(session, GameError.AuctionError("Energy grid is already owned"))
                }
                AuctionState(
                    energyGridId = command.energyGridId,
                    startedByPlayerId = command.startedByPlayerId,
                )
            }
            else -> return reject(session, GameError.AuctionError("Auction target missing"))
        }
        val updated = session.copy(auction = auction)
        return GameResult(
            updated,
            outcome = GameOutcome.PENDING_ACTION,
            pendingMessage = "Auction started for ${auction.assetId}",
        )
    }

    private fun handlePlaceBid(
        session: GameSession,
        command: GameCommand.PlaceAuctionBid,
    ): GameResult {
        val auction = session.auction
            ?: return reject(session, GameError.AuctionError("No auction in progress"))
        val player = session.players[command.playerId]
            ?: return reject(session, GameError.NotFound("Player", command.playerId))
        if (policies.auction.jailedPlayersCannotBid() && player.jailStatus) {
            return reject(session, GameError.AuctionError("Jailed players cannot bid"))
        }
        val expectedBid = auction.currentBid + banking.auctionBidIncrement
        if (command.bidAmount != expectedBid) {
            return reject(
                session,
                GameError.AuctionError(
                    "Bid must be ${com.boardbanker.core.money.MoneyFormatter.format(expectedBid, banking)} " +
                        "(${com.boardbanker.core.money.MoneyFormatter.format(banking.auctionBidIncrement, banking)} increments)",
                ),
            )
        }
        if (player.balance < command.bidAmount) {
            return reject(session, GameError.InsufficientFunds(command.playerId, command.bidAmount, player.balance))
        }
        val updated = session.copy(
            auction = auction.copy(
                currentBid = command.bidAmount,
                currentBidderId = command.playerId,
            ),
        )
        return GameResult(updated)
    }

    private fun handleCompleteAuction(session: GameSession): GameResult {
        val auction = session.auction
            ?: return reject(session, GameError.AuctionError("No auction in progress"))
        val winnerId = auction.currentBidderId
        if (winnerId == null) {
            return reject(session, GameError.AuctionError("No bids placed"))
        }
        val assetId = auction.assetId
        val bid = auction.currentBid
        val winner = session.players[winnerId]!!
        if (winner.balance < bid) {
            val debtResult = debtRules.enterDebtResolution(
                session = session.copy(auction = null),
                debtorId = winnerId,
                creditorId = EntityRef.BANK,
                amount = bid,
                reason = DebtReason.PURCHASE,
                propertyId = assetId,
            )
            if (!debtResult.isSuccess) {
                return reject(session, GameError.Validation(debtResult.error!!))
            }
            return GameResult(
                session = debtResult.session!!,
                outcome = GameOutcome.DEBT_RESOLUTION_REQUIRED,
                transactions = debtResult.transactions,
            )
        }
        val updatedWinner = winner.copy(balance = winner.balance - bid)
        var updated = session.copy(
            players = session.players + (winnerId to updatedWinner),
            auction = null,
        )
        updated = if (auction.propertyId != null) {
            updated.copy(
                properties = updated.properties + (
                    assetId to updated.properties[assetId]!!.copy(
                        ownerPlayerId = winnerId,
                        currentRentLevel = policies.auction.winnerInitialRentLevel(),
                    )
                ),
            )
        } else {
            updated.copy(
                energyGrids = updated.energyGrids + (
                    assetId to updated.energyGrids[assetId]!!.copy(ownerPlayerId = winnerId)
                ),
            )
        }
        val (tx, sessionAfter) = transactionFactory.create(
            session = updated,
            type = TransactionType.AUCTION_WIN,
            fromEntity = winnerId,
            toEntity = EntityRef.BANK,
            playerId = winnerId,
            propertyId = assetId,
            amount = bid,
        )
        updated = sessionAfter
        val bonusTransactions = if (auction.propertyId != null) {
            colorSetRules.applyCompletionBonusIfNeeded(updated, assetId, winnerId).let { bonus ->
                updated = bonus.session
                bonus.transactions
            }
        } else {
            emptyList()
        }
        return GameResult(updated, transactions = listOf(tx) + bonusTransactions)
    }

    private fun handleCancelAuction(session: GameSession): GameResult {
        if (session.auction == null) {
            return reject(session, GameError.AuctionError("No auction in progress"))
        }
        return GameResult(session.copy(auction = null))
    }

    private fun handleResolveDebt(
        session: GameSession,
        command: GameCommand.ResolveDebt,
    ): GameResult = handleResolveDebtWithProperties(
        session,
        GameCommand.ResolveDebtWithProperties(listOf(command.propertyId)),
    )

    private fun handleResolveDebtWithProperties(
        session: GameSession,
        command: GameCommand.ResolveDebtWithProperties,
    ): GameResult {
        val result = debtRules.resolveWithProperties(
            session,
            propertyIds = command.propertyIds,
            energyGridIds = command.energyGridIds,
        )
        if (!result.isSuccess) {
            return reject(session, GameError.DebtError(result.error!!))
        }
        val outcome = if (result.session!!.status == GameStatus.FINISHED) {
            GameOutcome.BANKRUPTCY
        } else if (result.session.debtResolution != null) {
            GameOutcome.DEBT_RESOLUTION_REQUIRED
        } else {
            GameOutcome.SUCCESS
        }
        return GameResult(result.session, outcome = outcome, transactions = result.transactions)
    }

    private fun handleCheckBankruptcy(
        session: GameSession,
        command: GameCommand.CheckBankruptcy,
    ): GameResult {
        val debt = session.debtResolution
            ?: return reject(session, GameError.DebtError("No debt resolution in progress"))
        val eventDebtId = debt.eventContributorDebt?.debtId
            ?: debt.eventDebt?.debtId
            ?: debt.eventBankDebit?.debtId
        val identityMatches = debt.debtorPlayerId == command.debtorPlayerId &&
            (eventDebtId == null ||
                (eventDebtId == command.debtId &&
                    session.pendingEventResolution?.resolutionId == command.eventResolutionId))
        if (!identityMatches) {
            return reject(session, GameError.DebtError("Bankruptcy request does not match the active debt"))
        }
        val contributorDebt = debt.eventContributorDebt
        if (contributorDebt != null) {
            val resolution = session.pendingEventResolution
            val settlement = session.pendingEventMultiContributorSettlement
            val obligation = resolution?.obligations?.firstOrNull {
                it.payerId == command.debtorPlayerId &&
                    it.recipientId == contributorDebt.recipientPlayerId
            }
            val validContributorObligation = resolution != null &&
                settlement != null &&
                resolution.resolutionId == command.eventResolutionId &&
                resolution.eventId == contributorDebt.eventId &&
                settlement.eventId == contributorDebt.eventId &&
                settlement.recipientPlayerId == contributorDebt.recipientPlayerId &&
                command.debtorPlayerId == contributorDebt.contributorPlayerId &&
                command.debtorPlayerId !in settlement.skippedContributorIds &&
                obligation?.status == com.boardbanker.core.model.EventObligationStatus.AWAITING_FUNDS
            if (!validContributorObligation) {
                return reject(session, GameError.DebtError("Bankruptcy request does not match the active Event obligation"))
            }
        }
        val result = debtRules.checkBankruptcyIfCannotResolve(session)
        if (!result.isSuccess) {
            return reject(session, GameError.DebtError(result.error!!))
        }
        val outcome = when {
            result.session!!.status == GameStatus.FINISHED -> GameOutcome.BANKRUPTCY
            result.session.debtResolution != null -> GameOutcome.DEBT_RESOLUTION_REQUIRED
            else -> GameOutcome.SUCCESS
        }
        return GameResult(result.session, outcome = outcome, transactions = result.transactions)
    }

    private fun handleUndo(session: GameSession): GameResult {
        if (!undoSupport.canUndo(session)) {
            return reject(session, GameError.UndoNotAllowed("Undo not allowed"))
        }
        val result = undoSupport.undo(session)
        if (!result.isSuccess) {
            return reject(session, GameError.UndoNotAllowed(result.error!!))
        }
        return GameResult(result.session!!, transactions = result.transactions)
    }

    private fun handleConcludeGame(session: GameSession): GameResult {
        if (session.status != GameStatus.ACTIVE) {
            return reject(session, GameError.GameFinished)
        }
        val winnerId = winnerCalculator.determineWinner(session)
        return GameResult(
            session.copy(
                status = GameStatus.FINISHED,
                winnerPlayerId = winnerId,
            ),
        )
    }

    private fun reject(session: GameSession, error: GameError): GameResult =
        GameResult(session, outcome = GameOutcome.REJECTED, error = error)

    private fun activeTurnLandingValidation(session: GameSession, playerId: String): GameError? {
        val activePlayerId = session.turnState?.activePlayerId?.takeIf { it.isNotBlank() } ?: return null
        if (playerId != activePlayerId) {
            return GameError.Validation("Only the active player can resolve landing during their turn.")
        }
        return null
    }

    private fun activeTurnBankActionValidation(session: GameSession, playerId: String): GameError? {
        val activePlayerId = session.turnState?.activePlayerId?.takeIf { it.isNotBlank() }
            ?: return GameError.Validation("No active player for bank action.")
        if (playerId != activePlayerId) {
            return GameError.NotActivePlayer(
                targetPlayerId = playerId,
                activePlayerId = activePlayerId,
            )
        }
        return null
    }

    private fun bankActionBlockedWhileJailed(session: GameSession, playerId: String): GameError? {
        JailGameplayGuard.boardActionBlockedMessage(definitions, session, playerId)?.let {
            return GameError.Validation(it)
        }
        return null
    }

    private fun extraTurnCancelledByJailPlayerIds(transactions: List<com.boardbanker.core.model.Transaction>): List<String> =
        transactions
            .filter { it.transactionType == TransactionType.EXTRA_TURN_CANCELLED_BY_JAIL }
            .mapNotNull { it.playerId }
}

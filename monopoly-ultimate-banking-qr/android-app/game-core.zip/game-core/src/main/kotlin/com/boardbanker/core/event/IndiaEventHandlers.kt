package com.boardbanker.core.event

import com.boardbanker.core.engine.PhysicalAction
import com.boardbanker.core.model.DiceGambleMode
import com.boardbanker.core.model.EntityRef
import com.boardbanker.core.model.EventActionDefinition
import com.boardbanker.core.model.LuckyBreakEventSnapshot
import com.boardbanker.core.model.LuckyBreakOutcome
import com.boardbanker.core.model.PhysicalDiceGambleOutcome
import com.boardbanker.core.model.GameDefinitions
import com.boardbanker.core.model.EventMultiPlayerTransferSnapshot
import com.boardbanker.core.model.GameSession
import com.boardbanker.core.model.PlayerOrder
import com.boardbanker.core.model.PendingDiceGamble
import com.boardbanker.core.model.PendingEnergyGridLanding
import com.boardbanker.core.model.PendingEventDraw
import com.boardbanker.core.rules.BoardTraversal
import com.boardbanker.core.model.PropertyState
import com.boardbanker.core.model.RentLevelChangeSnapshot
import com.boardbanker.core.model.Transaction
import com.boardbanker.core.model.TransactionType
import com.boardbanker.core.model.TurnKind
import com.boardbanker.core.rules.DebtRules
import com.boardbanker.core.rules.EventMultiPlayerTransferExecutor
import com.boardbanker.core.rules.GoRules
import com.boardbanker.core.model.JailStatusSnapshot
import com.boardbanker.core.rules.JailRules
import com.boardbanker.core.rules.RentLevelOperations
import com.boardbanker.core.rules.TurnScheduler
import com.boardbanker.core.transaction.TransactionFactory
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive

class IndiaEventHandlers(
    private val definitions: GameDefinitions,
    private val transactionFactory: TransactionFactory,
    private val debtRules: DebtRules,
    private val jailRules: JailRules,
    private val goRules: GoRules,
    private val turnScheduler: TurnScheduler,
) {
    private val rules = definitions.rules
    private val eventTransferExecutor = EventMultiPlayerTransferExecutor(definitions, transactionFactory)

    fun dispatch(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        propertyId: String?,
        targetPlayerId: String?,
        secondPropertyId: String?,
        secondPlayerId: String?,
        fromBoardPosition: Int? = null,
        timestamp: Long,
    ): EventEngine.EventResult = when (rule.actionType) {
        "MOVE_TO_SPACE" -> handleMoveToSpace(session, eventId, actingPlayerId, rule, timestamp)
        "MOVE_BACKWARD" -> handleMoveBackward(session, eventId, actingPlayerId, rule, timestamp)
        "BANK_CREDIT" -> handleBankCredit(session, eventId, actingPlayerId, rule.amount ?: 0, timestamp)
        "BANK_DEBIT" -> handleBankDebit(session, eventId, actingPlayerId, rule.amount ?: 0, timestamp)
        "PAY_EACH_PLAYER" -> handlePayEachPlayer(session, eventId, actingPlayerId, rule, timestamp)
        "COLLECT_FROM_EACH_PLAYER" -> handleCollectFromEachPlayer(session, eventId, actingPlayerId, rule, timestamp)
        "DEBIT_PER_OWNED_PROPERTY" -> handlePerOwnedProperty(
            session, eventId, actingPlayerId, rule.intParam("amountPerProperty") ?: rule.amount ?: 0, debit = true, timestamp,
        )
        "CREDIT_PER_OWNED_PROPERTY" -> handlePerOwnedProperty(
            session, eventId, actingPlayerId, rule.intParam("amountPerProperty") ?: rule.amount ?: 0, debit = false, timestamp,
        )
        "NEXT_RENT_WAIVER" -> handleNextRentWaiver(session, eventId, actingPlayerId, timestamp)
        "GET_OUT_OF_JAIL_PASS" -> handleJailPass(session, eventId, actingPlayerId, rule, timestamp)
        "MOVE_TO_JAIL" -> handleMoveToJail(session, eventId, actingPlayerId, rule, timestamp)
        "INCREASE_SELECTED_PROPERTY_RENT_LEVEL" -> handleSelectedPropertyRentChange(
            session, eventId, actingPlayerId, propertyId, +1, rule, timestamp,
        )
        "DECREASE_SELECTED_PROPERTY_RENT_LEVEL" -> handleSelectedPropertyRentChange(
            session, eventId, actingPlayerId, propertyId, -1, rule, timestamp,
        )
        "DRAW_ANOTHER_EVENT" -> handleDrawAnotherEvent(session, eventId, actingPlayerId, rule, timestamp)
        "COOPERATIVE_PROPERTY_UPGRADE" -> handleCooperativeUpgrade(
            session, eventId, actingPlayerId, propertyId, secondPropertyId, secondPlayerId ?: targetPlayerId, rule, timestamp,
        )
        "GAMBLE_ON_DICE_ROLL" -> handleGambleStart(session, eventId, actingPlayerId, rule, timestamp)
        "SKIP_NEXT_TURN" -> handleSkipNextTurn(session, eventId, actingPlayerId, timestamp)
        "FORCED_PROPERTY_SELLBACK" -> handleForcedSellback(
            session, eventId, actingPlayerId, propertyId, rule, timestamp,
        )
        "TOP_UP_BALANCE_TO_THRESHOLD" -> handleTopUpBalance(session, eventId, actingPlayerId, rule, timestamp)
        "MOVE_TO_NEAREST_STATION" -> handleMoveToNearestStation(
            session, eventId, actingPlayerId, rule, fromBoardPosition, timestamp,
        )
        "EXTRA_TURN" -> handleExtraTurn(session, eventId, actingPlayerId, rule, timestamp)
        "COMPLETE_COLOR_SET_BONUS_CREDIT" -> handleColorSetBonusCredit(session, eventId, actingPlayerId, rule, timestamp)
        else -> EventEngine.EventResult.failure(
            "Edition '${definitions.editionId}' event '$eventId': unsupported action '${rule.actionType}'",
        )
    }

    fun resetDiceGambleMode(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        timestamp: Long,
    ): EventEngine.EventResult {
        val pending = session.pendingDiceGamble
            ?: return EventEngine.EventResult.failure("No dice gamble in progress")
        if (pending.eventId != eventId || pending.actingPlayerId != actingPlayerId) {
            return EventEngine.EventResult.failure("Dice gamble state mismatch")
        }
        if (pending.completed) {
            return EventEngine.EventResult.failure("Dice gamble already completed")
        }
        if (pending.mode == null || pending.attemptsUsed > 0) {
            return EventEngine.EventResult.failure("Cannot reset dice gamble mode")
        }
        return EventEngine.EventResult.success(
            session.copy(pendingDiceGamble = pending.copy(mode = null)),
            emptyList(),
        )
    }

    fun selectDiceGambleMode(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        mode: DiceGambleMode,
        timestamp: Long,
    ): EventEngine.EventResult {
        val pending = session.pendingDiceGamble
            ?: return EventEngine.EventResult.failure("No dice gamble in progress")
        if (pending.eventId != eventId || pending.actingPlayerId != actingPlayerId) {
            return EventEngine.EventResult.failure("Dice gamble state mismatch")
        }
        if (pending.completed) {
            return EventEngine.EventResult.failure("Dice gamble already completed")
        }
        if (pending.mode != null) {
            return EventEngine.EventResult.failure("Dice gamble mode already selected")
        }
        return EventEngine.EventResult.success(
            session.copy(pendingDiceGamble = pending.copy(mode = mode)),
            emptyList(),
        )
    }

    fun resolvePhysicalDiceGamble(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        outcome: PhysicalDiceGambleOutcome,
        timestamp: Long,
    ): EventEngine.EventResult {
        val pending = session.pendingDiceGamble
            ?: return EventEngine.EventResult.failure("No dice gamble in progress")
        if (pending.eventId != eventId || pending.actingPlayerId != actingPlayerId) {
            return EventEngine.EventResult.failure("Dice gamble state mismatch")
        }
        if (pending.completed) {
            return EventEngine.EventResult.failure("Dice gamble already completed")
        }
        if (pending.mode != DiceGambleMode.PHYSICAL) {
            return EventEngine.EventResult.failure("Physical dice mode not selected")
        }
        return when (outcome) {
            PhysicalDiceGambleOutcome.JACKPOT -> completeGambleSuccess(
                session = session,
                pending = pending,
                diceResults = emptyList(),
                timestamp = timestamp,
                mode = DiceGambleMode.PHYSICAL,
                attemptNumber = 1,
            )
            PhysicalDiceGambleOutcome.PENALTY -> completeGambleFailure(
                session = session,
                pending = pending,
                diceResults = emptyList(),
                timestamp = timestamp,
                mode = DiceGambleMode.PHYSICAL,
                attemptNumber = pending.maximumAttempts,
            )
        }
    }

    fun rollDiceGamble(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        diceResults: List<Int>,
        timestamp: Long,
    ): EventEngine.EventResult {
        val pending = session.pendingDiceGamble
            ?: return EventEngine.EventResult.failure("No dice gamble in progress")
        if (pending.eventId != eventId || pending.actingPlayerId != actingPlayerId) {
            return EventEngine.EventResult.failure("Dice gamble state mismatch")
        }
        if (pending.completed) {
            return EventEngine.EventResult.failure("Dice gamble already completed")
        }
        if (pending.mode != DiceGambleMode.IN_APP) {
            return EventEngine.EventResult.failure("In-app dice mode not selected")
        }
        if (diceResults.size != pending.diceCount) {
            return EventEngine.EventResult.failure("Expected ${pending.diceCount} dice values")
        }
        if (diceResults.any { it !in 1..6 }) {
            return EventEngine.EventResult.failure("Dice values must be between 1 and 6")
        }
        val attemptsUsed = pending.attemptsUsed + 1
        val doubles = diceResults.size >= 2 && diceResults.distinct().size == 1
        if (doubles) {
            return completeGambleSuccess(
                session = session,
                pending = pending,
                diceResults = diceResults,
                timestamp = timestamp,
                mode = DiceGambleMode.IN_APP,
                attemptNumber = attemptsUsed,
            )
        }
        if (attemptsUsed >= pending.maximumAttempts) {
            return completeGambleFailure(
                session = session,
                pending = pending,
                diceResults = diceResults,
                timestamp = timestamp,
                mode = DiceGambleMode.IN_APP,
                attemptNumber = attemptsUsed,
            )
        }
        val updated = session.copy(
            pendingDiceGamble = pending.copy(
                attemptsUsed = attemptsUsed,
                lastRollResults = diceResults,
            ),
        )
        return EventEngine.EventResult.success(
            updated,
            emptyList(),
            pendingMessage = "Roll again (${attemptsUsed}/${pending.maximumAttempts})",
        )
    }

    private fun handleMoveToSpace(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val collectGo = rule.booleanParam("collectGoAmount") ?: false
        var updatedSession = session
        val transactions = mutableListOf<Transaction>()
        if (collectGo) {
            val goSalary = definitions.bankingValues.goSalary
            val creditResult = handleBankCredit(updatedSession, eventId, actingPlayerId, goSalary, timestamp)
            if (!creditResult.isSuccess) return creditResult
            updatedSession = creditResult.session!!
            transactions += creditResult.transactions
        }
        val physical = PhysicalAction(
            instruction = "Move directly to GO.",
            affectedPlayerIds = listOf(actingPlayerId),
            targetSpace = "GO",
        )
        return EventEngine.EventResult.success(updatedSession, transactions, listOf(physical))
    }

    private fun handleMoveBackward(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val spaces = rule.intParam("spaceCount") ?: 3
        val physical = PhysicalAction(
            instruction = "Move backward $spaces spaces, then scan the landed card. Do not collect GO salary.",
            affectedPlayerIds = listOf(actingPlayerId),
        )
        return EventEngine.EventResult.success(session, emptyList(), listOf(physical))
    }

    private fun handleBankCredit(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        amount: Int,
        timestamp: Long,
    ): EventEngine.EventResult = transferFromBank(session, eventId, actingPlayerId, amount, credit = true, timestamp)

    private fun handleBankDebit(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        amount: Int,
        timestamp: Long,
    ): EventEngine.EventResult = transferFromBank(session, eventId, actingPlayerId, amount, credit = false, timestamp)

    private fun transferFromBank(
        session: GameSession,
        eventId: String,
        playerId: String,
        amount: Int,
        credit: Boolean,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (amount <= 0) return EventEngine.EventResult.success(session, emptyList())
        val player = session.players[playerId] ?: return EventEngine.EventResult.failure("Unknown player")
        val resolution = session.pendingEventResolution
        if (!credit &&
            resolution?.eventId == eventId &&
            resolution.actingPlayerId == playerId &&
            resolution.bankDebitObligationPaid()
        ) {
            return EventEngine.EventResult.success(
                session.copy(
                    pendingEventExecution = null,
                    pendingEventResolution = null,
                ),
                emptyList(),
            )
        }
        if (!credit && player.balance < amount) {
            val eventName = definitions.events[eventId]?.name ?: eventId
            val debtResult = debtRules.enterEventBankDebitDebt(
                session = session,
                eventId = eventId,
                eventName = eventName,
                debtorId = playerId,
                amount = amount,
                timestamp = timestamp,
            )
            if (!debtResult.isSuccess) return EventEngine.EventResult.failure(debtResult.error ?: "Debt failed")
            return EventEngine.EventResult.success(debtResult.session!!, debtResult.transactions, needsDebtResolution = true)
        }
        val updatedPlayer = player.copy(balance = if (credit) player.balance + amount else player.balance - amount)
        var updatedSession = session.copy(players = session.players + (playerId to updatedPlayer))
        val txType = if (credit) TransactionType.BANK_CREDIT else TransactionType.BANK_DEBIT
        val (tx, sessionAfter) = transactionFactory.create(
            session = updatedSession,
            type = txType,
            timestamp = timestamp,
            fromEntity = if (credit) EntityRef.BANK else playerId,
            toEntity = if (credit) playerId else EntityRef.BANK,
            playerId = playerId,
            eventId = eventId,
            amount = amount,
            reversible = true,
        )
        return EventEngine.EventResult.success(sessionAfter.copy(undoSnapshot = session.snapshot()), listOf(tx))
    }

    private fun handlePayEachPlayer(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val amount = rule.intParam("amountPerOtherPlayer") ?: rule.amount ?: 0
        return transferBetweenPlayers(session, eventId, actingPlayerId, amount, payerIsActing = true, timestamp)
    }

    private fun handleCollectFromEachPlayer(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val amount = rule.intParam("amountPerOtherPlayer") ?: rule.amount ?: 0
        return transferBetweenPlayers(session, eventId, actingPlayerId, amount, payerIsActing = false, timestamp)
    }

    private fun transferBetweenPlayers(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        amount: Int,
        payerIsActing: Boolean,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (amount <= 0) return EventEngine.EventResult.success(session, emptyList())
        session.pendingEventResolution?.let { resolution ->
            if (resolution.isBankingRecordedFor(eventId, actingPlayerId)) {
                return EventEngine.EventResult.success(
                    session.copy(pendingEventExecution = null),
                    emptyList(),
                )
            }
        }
        val recipients = otherActivePlayers(session, actingPlayerId)
        if (recipients.isEmpty()) return EventEngine.EventResult.success(session, emptyList())
        val direction = if (payerIsActing) {
            EventMultiPlayerTransferSnapshot.Direction.PAY_EACH_PLAYER
        } else {
            EventMultiPlayerTransferSnapshot.Direction.COLLECT_FROM_EACH_PLAYER
        }
        val eventName = definitions.events[eventId]?.name ?: eventId

        if (payerIsActing) {
            val payer = session.players[actingPlayerId]!!
            val totalDue = amount * recipients.size
            if (payer.balance < totalDue) {
                val debtResult = debtRules.enterEventMultiRecipientDebt(
                    session = session,
                    eventId = eventId,
                    eventName = eventName,
                    payerPlayerId = actingPlayerId,
                    direction = direction,
                    amountPerRecipient = amount,
                    recipientPlayerIds = recipients,
                    timestamp = timestamp,
                )
                if (!debtResult.isSuccess) {
                    return EventEngine.EventResult.failure(debtResult.error ?: "Debt failed for $actingPlayerId")
                }
                return EventEngine.EventResult.success(
                    debtResult.session!!,
                    debtResult.transactions,
                    needsDebtResolution = true,
                )
            }
            val transferResult = eventTransferExecutor.execute(
                session = session,
                eventId = eventId,
                eventName = eventName,
                payerPlayerId = actingPlayerId,
                recipientPlayerIds = recipients,
                amountPerRecipient = amount,
                direction = direction,
                timestamp = timestamp,
            )
            return EventEngine.EventResult.success(
                transferResult.session.copy(undoSnapshot = session.snapshot()),
                transferResult.transactions,
            )
        }

        val settlementResult = debtRules.processEventMultiContributorSettlement(
            session = session,
            eventId = eventId,
            eventName = eventName,
            recipientPlayerId = actingPlayerId,
            amountPerContributor = amount,
            contributorPlayerIds = recipients,
            timestamp = timestamp,
        )
        if (!settlementResult.isSuccess) {
            return EventEngine.EventResult.failure(settlementResult.error ?: "Birthday settlement failed")
        }
        val needsDebt = settlementResult.session!!.debtResolution != null
        return EventEngine.EventResult.success(
            settlementResult.session!!.copy(undoSnapshot = session.snapshot()),
            settlementResult.transactions,
            needsDebtResolution = needsDebt,
        )
    }

    private fun handlePerOwnedProperty(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        amountPerProperty: Int,
        debit: Boolean,
        timestamp: Long,
    ): EventEngine.EventResult {
        val ownedCount = session.properties.values.count { it.ownerPlayerId == actingPlayerId }
        val total = ownedCount * amountPerProperty
        return if (debit) {
            handleBankDebit(session, eventId, actingPlayerId, total, timestamp)
        } else {
            handleBankCredit(session, eventId, actingPlayerId, total, timestamp)
        }
    }

    private fun handleNextRentWaiver(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        timestamp: Long,
    ): EventEngine.EventResult {
        val player = session.players[actingPlayerId]!!
        if (player.pendingRentWaiver) {
            return EventEngine.EventResult.success(session, emptyList())
        }
        val updated = player.copy(
            pendingRentWaiver = true,
            rentWaiverSourceEventId = eventId,
        )
        return EventEngine.EventResult.success(
            session.copy(
                players = session.players + (actingPlayerId to updated),
                undoSnapshot = session.snapshot(),
            ),
            emptyList(),
        )
    }

    private fun handleJailPass(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val player = session.players[actingPlayerId]!!
        if (player.jailPassCount > 0) {
            return EventEngine.EventResult.success(session, emptyList())
        }
        val updated = player.copy(jailPassCount = rule.intParam("passCount") ?: 1)
        return EventEngine.EventResult.success(
            session.copy(
                players = session.players + (actingPlayerId to updated),
                undoSnapshot = session.snapshot(),
            ),
            emptyList(),
        )
    }

    private fun handleMoveToJail(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val player = session.players[actingPlayerId]
            ?: return EventEngine.EventResult.failure("Unknown player")
        if (player.jailStatus) {
            return EventEngine.EventResult.failure("Player is already in Jail")
        }

        val preActionSnapshot = session.snapshot()
        val jailResult = jailRules.sendToJail(session, actingPlayerId, timestamp)
        if (!jailResult.isSuccess) return EventEngine.EventResult.failure(jailResult.error ?: "Jail failed")

        var updatedSession = jailResult.session!!
        val transactions = jailResult.transactions.toMutableList()
        var skippedTurnPlayerIds = emptyList<String>()
        var extraTurnStartedPlayerId: String? = null
        var extraTurnCancelledBySkipPlayerId: String? = null

        val wasNewlyJailed = transactions.any {
            it.transactionType == TransactionType.JAIL_STATUS_CHANGE &&
                JailStatusSnapshot.enteredJail(it)
        }
        if (rule.booleanParam("endCurrentTurn") == true && wasNewlyJailed) {
            val turnResult = turnScheduler.endTurn(updatedSession, actingPlayerId, timestamp)
            if (!turnResult.isSuccess) {
                return EventEngine.EventResult.failure(turnResult.error ?: "Turn advance failed")
            }
            updatedSession = turnResult.session!!
            transactions += turnResult.transactions
            skippedTurnPlayerIds = turnResult.skippedTurnPlayerIds
            extraTurnStartedPlayerId = turnResult.extraTurnStartedPlayerId
            extraTurnCancelledBySkipPlayerId = turnResult.extraTurnCancelledBySkipPlayerId
        }

        val physical = PhysicalAction(
            instruction = "Move directly to Jail without collecting GO salary. End your current turn.",
            affectedPlayerIds = listOf(actingPlayerId),
            targetSpace = "JAIL",
        )
        return EventEngine.EventResult.success(
            session = updatedSession.copy(undoSnapshot = preActionSnapshot),
            transactions = transactions,
            physicalActions = listOf(physical),
            skippedTurnPlayerIds = skippedTurnPlayerIds,
            extraTurnStartedPlayerId = extraTurnStartedPlayerId,
            extraTurnCancelledBySkipPlayerId = extraTurnCancelledBySkipPlayerId,
        )
    }

    private fun handleSelectedPropertyRentChange(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        propertyId: String?,
        delta: Int,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (propertyId == null) return EventEngine.EventResult.failure("Property scan required")
        val propertyState = session.properties[propertyId] ?: return EventEngine.EventResult.failure("Unknown property")
        if (propertyState.ownerPlayerId != actingPlayerId) {
            return EventEngine.EventResult.failure("Property must be owned by acting player")
        }
        val oldLevel = propertyState.currentRentLevel
        val newLevel = if (delta > 0) {
            RentLevelOperations.increaseLevel(oldLevel, 1, rules.maximumRentLevel)
        } else {
            RentLevelOperations.decreaseLevel(oldLevel, 1, rules.minimumRentLevel)
        }
        if (newLevel == oldLevel) {
            return EventEngine.EventResult.success(session, emptyList())
        }
        val updatedProperties = session.properties + (propertyId to propertyState.copy(currentRentLevel = newLevel))
        var updatedSession = session.copy(properties = updatedProperties, undoSnapshot = session.snapshot())
        val (tx, sessionAfter) = transactionFactory.create(
            session = updatedSession,
            type = TransactionType.PROPERTY_RENT_LEVEL_CHANGE,
            timestamp = timestamp,
            playerId = actingPlayerId,
            propertyId = propertyId,
            eventId = eventId,
            amount = newLevel,
            stateBefore = RentLevelChangeSnapshot.stateBefore(oldLevel),
            stateAfter = RentLevelChangeSnapshot.stateAfter(newLevel),
        )
        return EventEngine.EventResult.success(sessionAfter, listOf(tx))
    }

    private fun handleDrawAnotherEvent(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (session.pendingEventDraw != null) {
            return EventEngine.EventResult.failure("Event draw already pending")
        }
        val pending = PendingEventDraw(
            parentEventId = eventId,
            actingPlayerId = actingPlayerId,
            remainingDraws = 1,
        )
        val physical = PhysicalAction(
            instruction = "Scan the additional Event Card and resolve it completely.",
            affectedPlayerIds = listOf(actingPlayerId),
        )
        return EventEngine.EventResult.success(
            session.copy(
                pendingEventDraw = pending,
                eventChainDepth = 0,
                undoSnapshot = session.snapshot(),
            ),
            emptyList(),
            listOf(physical),
            pendingMessage = "Scan the additional Event Card",
        )
    }

    private fun handleCooperativeUpgrade(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        propertyId: String?,
        secondPropertyId: String?,
        otherPlayerId: String?,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (propertyId == null || secondPropertyId == null || otherPlayerId == null) {
            return EventEngine.EventResult.failure("Two players and two properties required")
        }
        if (propertyId == secondPropertyId) {
            return EventEngine.EventResult.failure("Select two different properties")
        }
        val first = session.properties[propertyId] ?: return EventEngine.EventResult.failure("Unknown property")
        val second = session.properties[secondPropertyId] ?: return EventEngine.EventResult.failure("Unknown second property")
        if (first.ownerPlayerId != actingPlayerId) {
            return EventEngine.EventResult.failure("First property must be owned by acting player")
        }
        if (second.ownerPlayerId != otherPlayerId) {
            return EventEngine.EventResult.failure("Second property must be owned by the selected player")
        }
        val changes = mutableMapOf<String, Int>()
        for ((id, state) in listOf(propertyId to first, secondPropertyId to second)) {
            val newLevel = RentLevelOperations.increaseLevel(state.currentRentLevel, 1, rules.maximumRentLevel)
            if (newLevel == state.currentRentLevel) {
                return EventEngine.EventResult.success(session, emptyList())
            }
            changes[id] = newLevel
        }
        var updatedSession = session.copy(
            properties = RentLevelOperations.applyRentLevelChanges(session.properties, changes),
            undoSnapshot = session.snapshot(),
        )
        val transactions = changes.map { (id, newLevel) ->
            val oldLevel = session.properties[id]!!.currentRentLevel
            val (tx, sessionAfter) = transactionFactory.create(
                session = updatedSession,
                type = TransactionType.PROPERTY_RENT_LEVEL_CHANGE,
                timestamp = timestamp,
                playerId = session.properties[id]!!.ownerPlayerId,
                propertyId = id,
                eventId = eventId,
                amount = newLevel,
                stateBefore = RentLevelChangeSnapshot.stateBefore(oldLevel),
                stateAfter = RentLevelChangeSnapshot.stateAfter(newLevel),
            )
            updatedSession = sessionAfter
            tx
        }
        return EventEngine.EventResult.success(updatedSession, transactions)
    }

    private fun handleGambleStart(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (session.pendingDiceGamble != null) {
            return EventEngine.EventResult.failure("Dice gamble already in progress")
        }
        val pending = PendingDiceGamble(
            eventId = eventId,
            actingPlayerId = actingPlayerId,
            attemptsUsed = 0,
            maximumAttempts = rule.intParam("maximumAttempts") ?: 3,
            jackpotAmount = rule.intParam("jackpotAmount") ?: 0,
            penaltyAmount = rule.intParam("penaltyAmount") ?: 0,
            diceCount = rule.intParam("diceCount") ?: 2,
        )
        return EventEngine.EventResult.success(
            session.copy(pendingDiceGamble = pending, undoSnapshot = session.snapshot()),
            emptyList(),
            pendingMessage = "Roll Dice",
        )
    }

    private fun completeGambleSuccess(
        session: GameSession,
        pending: PendingDiceGamble,
        diceResults: List<Int>,
        timestamp: Long,
        mode: DiceGambleMode,
        attemptNumber: Int,
    ): EventEngine.EventResult {
        val cleared = session.copy(pendingDiceGamble = pending.copy(lastRollResults = diceResults, completed = true))
        val eventName = definitions.events[pending.eventId]?.name ?: "Lucky Break"
        val resolutionId = "${session.gameId}_LB_${session.transactionCounter + 1}"
        val credit = transferLuckyBreakBank(
            session = cleared,
            eventId = pending.eventId,
            eventName = eventName,
            playerId = pending.actingPlayerId,
            amount = pending.jackpotAmount,
            credit = true,
            mode = mode,
            outcome = LuckyBreakOutcome.JACKPOT,
            attemptNumber = attemptNumber,
            resolutionId = resolutionId,
            dieOne = diceResults.getOrNull(0),
            dieTwo = diceResults.getOrNull(1),
            timestamp = timestamp,
        )
        return credit.copy(
            session = credit.session?.copy(pendingDiceGamble = null),
        )
    }

    private fun completeGambleFailure(
        session: GameSession,
        pending: PendingDiceGamble,
        diceResults: List<Int>,
        timestamp: Long,
        mode: DiceGambleMode,
        attemptNumber: Int,
    ): EventEngine.EventResult {
        val cleared = session.copy(pendingDiceGamble = pending.copy(lastRollResults = diceResults, completed = true))
        val eventName = definitions.events[pending.eventId]?.name ?: "Lucky Break"
        val resolutionId = "${session.gameId}_LB_${session.transactionCounter + 1}"
        val debit = transferLuckyBreakBank(
            session = cleared,
            eventId = pending.eventId,
            eventName = eventName,
            playerId = pending.actingPlayerId,
            amount = pending.penaltyAmount,
            credit = false,
            mode = mode,
            outcome = LuckyBreakOutcome.PENALTY,
            attemptNumber = attemptNumber,
            resolutionId = resolutionId,
            dieOne = diceResults.getOrNull(0),
            dieTwo = diceResults.getOrNull(1),
            timestamp = timestamp,
        )
        return debit.copy(
            session = debit.session?.copy(pendingDiceGamble = null),
        )
    }

    private fun transferLuckyBreakBank(
        session: GameSession,
        eventId: String,
        eventName: String,
        playerId: String,
        amount: Int,
        credit: Boolean,
        mode: DiceGambleMode,
        outcome: LuckyBreakOutcome,
        attemptNumber: Int,
        resolutionId: String,
        dieOne: Int?,
        dieTwo: Int?,
        timestamp: Long,
    ): EventEngine.EventResult {
        if (amount <= 0) return EventEngine.EventResult.success(session, emptyList())
        val player = session.players[playerId] ?: return EventEngine.EventResult.failure("Unknown player")
        if (!credit && player.balance < amount) {
            val debtResult = debtRules.enterDebtResolution(
                session = session,
                debtorId = playerId,
                creditorId = EntityRef.BANK,
                amount = amount,
                timestamp = timestamp,
            )
            if (!debtResult.isSuccess) return EventEngine.EventResult.failure(debtResult.error ?: "Debt failed")
            val debtSession = debtResult.session!!
            val existingResolution = debtSession.transactions.any {
                LuckyBreakEventSnapshot.fromTransaction(it)?.resolutionId == resolutionId
            }
            if (existingResolution) {
                return EventEngine.EventResult.failure("Lucky Break already resolved")
            }
            return EventEngine.EventResult.success(debtSession, debtResult.transactions, needsDebtResolution = true)
        }
        val updatedPlayer = player.copy(balance = if (credit) player.balance + amount else player.balance - amount)
        var updatedSession = session.copy(players = session.players + (playerId to updatedPlayer))
        val txType = if (credit) TransactionType.BANK_CREDIT else TransactionType.BANK_DEBIT
        val stateAfter = LuckyBreakEventSnapshot.stateAfter(
            playerId = playerId,
            eventId = eventId,
            eventName = eventName,
            mode = mode,
            outcome = outcome,
            appliedAmount = amount,
            attemptNumber = attemptNumber,
            resolutionId = resolutionId,
            dieOne = dieOne,
            dieTwo = dieTwo,
        )
        val (tx, sessionAfter) = transactionFactory.create(
            session = updatedSession,
            type = txType,
            timestamp = timestamp,
            fromEntity = if (credit) EntityRef.BANK else playerId,
            toEntity = if (credit) playerId else EntityRef.BANK,
            playerId = playerId,
            eventId = eventId,
            amount = amount,
            stateAfter = stateAfter,
            reversible = true,
        )
        return EventEngine.EventResult.success(sessionAfter.copy(undoSnapshot = session.snapshot()), listOf(tx))
    }

    private fun handleSkipNextTurn(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        timestamp: Long,
    ): EventEngine.EventResult {
        val player = session.players[actingPlayerId]!!
        if (player.pendingSkipTurnCount > 0) {
            return EventEngine.EventResult.success(session, emptyList())
        }
        val updated = player.copy(pendingSkipTurnCount = 1)
        return EventEngine.EventResult.success(
            session.copy(
                players = session.players + (actingPlayerId to updated),
                undoSnapshot = session.snapshot(),
            ),
            emptyList(),
        )
    }

    private fun handleForcedSellback(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        propertyId: String?,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val selection = ForcedPropertySellbackSelection.resolve(session, definitions, actingPlayerId)
        if (selection.ownedPropertyIds.isEmpty()) return EventEngine.EventResult.success(session, emptyList())
        val selectedId = selection.autoSelectedPropertyId
            ?: propertyId?.takeIf { it in selection.lowestValueCandidates }
            ?: return EventEngine.EventResult.failure("Select one of your lowest-value properties")
        val propertyDef = definitions.properties[selectedId]!!
        val multiplier = rule.doubleParam("payoutMultiplier") ?: 2.0
        val payout = (propertyDef.purchasePrice * multiplier).toInt()
        val propertyState = session.properties[selectedId]!!
        val initialLevel = propertyDef.initialRentLevel
        var updatedSession = session.copy(
            properties = session.properties + (
                selectedId to PropertyState(
                    propertyId = selectedId,
                    ownerPlayerId = null,
                    currentRentLevel = initialLevel,
                )
            ),
            temporaryEffects = session.temporaryEffects.filterNot {
                it.targetScope == selectedId
            },
            undoSnapshot = session.snapshot(),
        )
        val credit = handleBankCredit(updatedSession, eventId, actingPlayerId, payout, timestamp)
        return credit
    }

    private fun handleTopUpBalance(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val threshold = rule.intParam("thresholdAmount") ?: rule.amount ?: 0
        val player = session.players[actingPlayerId]!!
        if (player.balance >= threshold) {
            return EventEngine.EventResult.success(session, emptyList())
        }
        val topUp = threshold - player.balance
        return handleBankCredit(session, eventId, actingPlayerId, topUp, timestamp)
    }

    private fun handleMoveToNearestStation(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        fromBoardPosition: Int?,
        timestamp: Long,
    ): EventEngine.EventResult {
        val rawSemantic = rule.parameters["stationSemanticType"]?.jsonPrimitive?.content
        val semanticType = when (rawSemantic) {
            "ENERGY_STATION", "ENERGY_GRID", null -> "ENERGY_GRID"
            else -> rawSemantic
        }
        if (semanticType != "ENERGY_GRID") {
            return EventEngine.EventResult.failure("Unsupported station semantic type: $semanticType")
        }
        if (definitions.energyGrids.isEmpty()) {
            val physical = PhysicalAction(
                instruction = "Move forward to the next Energy Grid, then scan the landed card.",
                affectedPlayerIds = listOf(actingPlayerId),
            )
            return EventEngine.EventResult.success(session, emptyList(), listOf(physical))
        }
        if (fromBoardPosition == null) {
            val physical = PhysicalAction(
                instruction = "Move forward to the next Energy Grid, then scan the landed card.",
                affectedPlayerIds = listOf(actingPlayerId),
            )
            return EventEngine.EventResult.success(session, emptyList(), listOf(physical))
        }
        val layout = definitions.boardLayout
        if (fromBoardPosition !in 0 until layout.size) {
            return EventEngine.EventResult.failure("Invalid board position: $fromBoardPosition")
        }
        val targetSpace = BoardTraversal.nextEnergyGridSpace(definitions, fromBoardPosition)
            ?: return EventEngine.EventResult.failure("No energy grid space found on board")
        val targetGridId = targetSpace.targetId
            ?: return EventEngine.EventResult.failure("Energy grid space is missing targetId")
        if (!definitions.energyGrids.containsKey(targetGridId)) {
            return EventEngine.EventResult.failure("Unknown energy grid on board: $targetGridId")
        }

        var updatedSession = session
        val transactions = mutableListOf<Transaction>()
        val collectGo = rule.booleanParam("collectGoIfPassed") ?: true
        if (collectGo && BoardTraversal.passedGoOnForwardMove(fromBoardPosition, targetSpace.position)) {
            val goSalary = definitions.bankingValues.goSalary
            val creditResult = handleBankCredit(updatedSession, eventId, actingPlayerId, goSalary, timestamp)
            if (!creditResult.isSuccess) return creditResult
            updatedSession = creditResult.session!!
            transactions += creditResult.transactions
        }

        val grid = definitions.energyGrids[targetGridId]!!
        val boardNumber = layout.boardNumberForEnergyGrid(targetGridId)
        val displayName = if (boardNumber != null) "[$boardNumber] ${grid.name}" else grid.name
        updatedSession = updatedSession.copy(
            undoSnapshot = session.snapshot(),
            pendingEnergyGridLanding = PendingEnergyGridLanding(
                actingPlayerId = actingPlayerId,
                energyGridId = targetGridId,
                sourceEventId = eventId,
            ),
        )
        val physical = PhysicalAction(
            instruction = "Move forward to $displayName, then scan the Energy Grid card.",
            affectedPlayerIds = listOf(actingPlayerId),
            targetSpace = targetSpace.spaceId,
        )
        return EventEngine.EventResult.success(updatedSession, transactions, listOf(physical))
    }

    private fun handleExtraTurn(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val player = session.players[actingPlayerId]!!
        val stackBehaviour = rule.parameters["stackBehaviour"]?.jsonPrimitive?.content ?: "DO_NOT_STACK"
        if (stackBehaviour == "DO_NOT_STACK") {
            if (player.pendingExtraTurn) {
                return EventEngine.EventResult.success(session, emptyList())
            }
            val turnState = session.turnState
            if (turnState?.activePlayerId == actingPlayerId && turnState.turnKind == TurnKind.EXTRA) {
                return EventEngine.EventResult.success(session, emptyList())
            }
        }
        val updated = player.copy(pendingExtraTurn = true)
        var updatedSession = session.copy(
            players = session.players + (actingPlayerId to updated),
            undoSnapshot = session.snapshot(),
        )
        val (grantTx, sessionAfterGrant) = transactionFactory.create(
            session = updatedSession,
            type = TransactionType.EXTRA_TURN_GRANTED,
            timestamp = timestamp,
            playerId = actingPlayerId,
            eventId = eventId,
            reversible = true,
        )
        return EventEngine.EventResult.success(sessionAfterGrant, listOf(grantTx))
    }

    private fun handleColorSetBonusCredit(
        session: GameSession,
        eventId: String,
        actingPlayerId: String,
        rule: EventActionDefinition,
        timestamp: Long,
    ): EventEngine.EventResult {
        val completeGroups = definitions.boardRelationships.colorGroups.filter { (_, propertyIds) ->
            propertyIds.isNotEmpty() && propertyIds.all { id ->
                session.properties[id]?.ownerPlayerId == actingPlayerId
            }
        }
        if (completeGroups.isEmpty()) {
            return EventEngine.EventResult.success(session, emptyList())
        }
        val base = rule.intParam("baseRebateAmount") ?: rule.amount ?: 0
        val multiplier = rule.doubleParam("rewardMultiplier") ?: 1.0
        val maxCredit = rule.intParam("maximumCreditAmount")
        var credit = (base * multiplier).toInt()
        if (maxCredit != null) {
            credit = minOf(credit, maxCredit)
        }
        return handleBankCredit(session, eventId, actingPlayerId, credit, timestamp)
    }

    private fun otherActivePlayers(session: GameSession, actingPlayerId: String): List<String> =
        PlayerOrder.displayOrder(session).filter { playerId ->
            val player = session.players[playerId]
            player != null && player.active && !player.bankrupt && playerId != actingPlayerId
        }

    private fun EventActionDefinition.intParam(key: String): Int? =
        parameters[key]?.jsonPrimitive?.intOrNull

    private fun EventActionDefinition.booleanParam(key: String): Boolean? =
        parameters[key]?.jsonPrimitive?.booleanOrNull

    private fun EventActionDefinition.doubleParam(key: String): Double? =
        parameters[key]?.jsonPrimitive?.doubleOrNull
}
